﻿namespace Miner.Views
{
    public struct MiningData
    {
        public string MiningString { get; set; }
        public int Length { get; set; }
        public string Hash { get; set; }
    }
}
